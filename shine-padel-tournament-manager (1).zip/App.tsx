
import React, { useState, useEffect } from 'react';
import { Group, GroupMatch, KnockoutTeam, KnockoutMatch, Standing, Player } from './types';
import { INITIAL_GROUPS, TEAM_COMPOSITIONS, INITIAL_KNOCKOUT_MATCHES, SCHEDULE, FUNNY_RULES } from './constants';
import GroupView from './components/GroupView';
import BracketView from './components/BracketView';
import RankingView from './components/RankingView';
import PlayerListView from './components/PlayerListView';
import Hero from './components/Hero';
import RulesModal from './components/RulesModal';
import LoginModal from './components/LoginModal';
import { Users, Calendar, Trophy, Lock, Unlock, BarChart3, List } from 'lucide-react';

// Generates 2v2 Americano style matches for 4 players
// Match 1: P1 & P2 vs P3 & P4
// Match 2: P1 & P3 vs P2 & P4
// Match 3: P1 & P4 vs P2 & P3
const generateMatchesForGroup = (players: Player[], groupId: number): GroupMatch[] => {
  if (players.length < 4) return [];

  const p = players;
  const matches: GroupMatch[] = [
    {
      id: `g${groupId}-m1`,
      player1Id: p[0].id, player2Id: p[1].id, // Team A
      player3Id: p[2].id, player4Id: p[3].id, // Team B
      result: null, status: 'scheduled'
    },
    {
      id: `g${groupId}-m2`,
      player1Id: p[0].id, player2Id: p[2].id, // Team A
      player3Id: p[1].id, player4Id: p[3].id, // Team B
      result: null, status: 'scheduled'
    },
    {
      id: `g${groupId}-m3`,
      player1Id: p[0].id, player2Id: p[3].id, // Team A
      player3Id: p[1].id, player4Id: p[2].id, // Team B
      result: null, status: 'scheduled'
    }
  ];
  return matches;
};

// Helper to calc standings for a specific group
const getGroupStandings = (group: Group): Standing[] => {
  const players = group.players;
  const matches = group.matches;
  const standings: Record<string, Standing> = {};
  
  players.forEach(p => {
    standings[p.id] = { playerId: p.id, points: 0, played: 0, won: 0, lost: 0, gamesWon: 0, gamesLost: 0, diff: 0 };
  });

  matches.forEach(m => {
    if (m.status === 'finished' && m.result) {
      const { scoreA, scoreB, isTieBreakWin } = m.result;
      
      // Team A Players
      const p1 = standings[m.player1Id];
      const p2 = standings[m.player2Id];
      // Team B Players
      const p3 = standings[m.player3Id];
      const p4 = standings[m.player4Id];

      if(p1 && p2 && p3 && p4) {
        // Update stats for all 4 players
        [p1, p2].forEach(p => {
          p.played++; 
          p.gamesWon += scoreA; 
          p.gamesLost += scoreB; 
          p.diff += (scoreA - scoreB);
        });

        [p3, p4].forEach(p => {
          p.played++; 
          p.gamesWon += scoreB; 
          p.gamesLost += scoreA; 
          p.diff += (scoreB - scoreA);
        });

        if (scoreA > scoreB) {
          // Team A Wins
          [p1, p2].forEach(p => {
             p.won++; 
             p.points += isTieBreakWin ? 2 : 3;
          });
          [p3, p4].forEach(p => {
             p.lost++; 
             p.points += 1;
          });
        } else {
          // Team B Wins
          [p3, p4].forEach(p => {
             p.won++; 
             p.points += isTieBreakWin ? 2 : 3;
          });
          [p1, p2].forEach(p => {
             p.lost++; 
             p.points += 1;
          });
        }
      }
    }
  });

  return Object.values(standings).sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.diff !== a.diff) return b.diff - a.diff;
    return b.gamesWon - a.gamesWon;
  });
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'groups' | 'bracket' | 'ranking' | 'players' | 'schedule'>('groups');
  const [selectedGroup, setSelectedGroup] = useState<number>(1);
  const [groups, setGroups] = useState<Group[]>([]);
  const [knockoutMatches, setKnockoutMatches] = useState<KnockoutMatch[]>(INITIAL_KNOCKOUT_MATCHES);
  
  // Modals
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Initialize teams from constants
  const [bracketTeams, setBracketTeams] = useState<Record<string, KnockoutTeam>>(() => {
    const teams: Record<string, KnockoutTeam> = {};
    TEAM_COMPOSITIONS.forEach(c => {
      teams[c.id] = { 
        ...c, 
        name: `Equipa ${c.id}`, 
        player1: null, 
        player2: null, 
        compositionRule: `${c.pos1}º Grupo ${c.g1} & ${c.pos2}º Grupo ${c.g2}` 
      };
    });
    return teams;
  });

  // Admin State
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Initialize Groups with matches only once
  useEffect(() => {
    const initializedGroups = INITIAL_GROUPS.map(g => ({
      ...g,
      matches: generateMatchesForGroup(g.players, g.id)
    }));
    setGroups(initializedGroups);
  }, []);

  const handleUpdateMatch = (groupId: number, updatedMatch: GroupMatch) => {
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return {
        ...g,
        matches: g.matches.map(m => m.id === updatedMatch.id ? updatedMatch : m)
      };
    }));
  };

  const handleAddPlayer = (groupId: number, name: string, level: string) => {
    setGroups(prevGroups => prevGroups.map(group => {
      if (group.id !== groupId) return group;

      const newPlayerId = `${groupId}-${Date.now()}`;
      const newPlayer: Player = {
        id: newPlayerId,
        name: name,
        level: level,
        groupId: groupId
      };
      
      return {
        ...group,
        players: [...group.players, newPlayer]
      };
    }));
  };

  const handleAddMatch = (groupId: number) => {
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      // Default to first 4 players if available, otherwise empty strings
      // This ensures the match is visible and editable.
      const p = g.players;
      const newMatch: GroupMatch = {
        id: `manual-${Date.now()}`,
        player1Id: p[0]?.id || '',
        player2Id: p[1]?.id || '',
        player3Id: p[2]?.id || '',
        player4Id: p[3]?.id || '',
        result: null,
        status: 'scheduled'
      };
      return { ...g, matches: [...g.matches, newMatch] };
    }));
  };

  const handleLogin = (success: boolean) => {
    setIsAdmin(success);
  };

  const handleLogout = () => {
    setIsAdmin(false);
  };

  // --- Bracket Logic ---

  const handlePopulateBracket = () => {
    if (!isAdmin) return;
    if (!window.confirm("Isto irá atualizar os Oitavos de Final com base na classificação atual dos grupos. Continuar?")) return;

    const newTeams = { ...bracketTeams };
    
    TEAM_COMPOSITIONS.forEach(comp => {
      const g1 = groups.find(g => g.id === comp.g1);
      const g1Standings = g1 ? getGroupStandings(g1) : [];
      const p1Id = g1Standings[comp.pos1 - 1]?.playerId;
      const p1 = g1?.players.find(p => p.id === p1Id) || null;

      const g2 = groups.find(g => g.id === comp.g2);
      const g2Standings = g2 ? getGroupStandings(g2) : [];
      const p2Id = g2Standings[comp.pos2 - 1]?.playerId;
      const p2 = g2?.players.find(p => p.id === p2Id) || null;

      if (newTeams[comp.id]) {
        newTeams[comp.id] = {
           ...newTeams[comp.id],
           player1: p1,
           player2: p2
        };
      }
    });

    setBracketTeams(newTeams);
    alert("Equipas dos Oitavos de Final atualizadas!");
  };

  const generateNextRound = (currentRoundMatches: string[], nextRoundMatches: string[]) => {
      const updatedMatches = [...knockoutMatches];
      
      // Map previous match ID to its winner
      const winners: Record<string, string> = {};
      
      currentRoundMatches.forEach(mid => {
          const match = updatedMatches.find(m => m.id === mid);
          if (match && match.winnerTeamId) {
              winners[mid] = match.winnerTeamId;
          }
      });

      // Update next round
      // Hardcoded map based on standard bracket logic
      // Q1 (M9) comes from M1 & M2
      // Q2 (M10) comes from M3 & M4
      // Q3 (M11) comes from M5 & M6
      // Q4 (M12) comes from M7 & M8
      
      // S1 (M13) comes from M9 & M10
      // S2 (M14) comes from M11 & M12
      
      // F1 (M15) comes from M13 & M14

      if (nextRoundMatches.includes('match_9')) {
         const m9Index = updatedMatches.findIndex(m => m.id === 'match_9');
         if (m9Index >= 0) updatedMatches[m9Index] = { ...updatedMatches[m9Index], teamAId: winners['match_1'] || 'TBD', teamBId: winners['match_2'] || 'TBD' };
         
         const m10Index = updatedMatches.findIndex(m => m.id === 'match_10');
         if (m10Index >= 0) updatedMatches[m10Index] = { ...updatedMatches[m10Index], teamAId: winners['match_3'] || 'TBD', teamBId: winners['match_4'] || 'TBD' };

         const m11Index = updatedMatches.findIndex(m => m.id === 'match_11');
         if (m11Index >= 0) updatedMatches[m11Index] = { ...updatedMatches[m11Index], teamAId: winners['match_5'] || 'TBD', teamBId: winners['match_6'] || 'TBD' };

         const m12Index = updatedMatches.findIndex(m => m.id === 'match_12');
         if (m12Index >= 0) updatedMatches[m12Index] = { ...updatedMatches[m12Index], teamAId: winners['match_7'] || 'TBD', teamBId: winners['match_8'] || 'TBD' };
      }

      if (nextRoundMatches.includes('match_13')) {
          const m13Index = updatedMatches.findIndex(m => m.id === 'match_13');
          if (m13Index >= 0) updatedMatches[m13Index] = { ...updatedMatches[m13Index], teamAId: winners['match_9'] || 'TBD', teamBId: winners['match_10'] || 'TBD' };
 
          const m14Index = updatedMatches.findIndex(m => m.id === 'match_14');
          if (m14Index >= 0) updatedMatches[m14Index] = { ...updatedMatches[m14Index], teamAId: winners['match_11'] || 'TBD', teamBId: winners['match_12'] || 'TBD' };
      }

      if (nextRoundMatches.includes('match_15')) {
          const m15Index = updatedMatches.findIndex(m => m.id === 'match_15');
          if (m15Index >= 0) updatedMatches[m15Index] = { ...updatedMatches[m15Index], teamAId: winners['match_13'] || 'TBD', teamBId: winners['match_14'] || 'TBD' };
      }

      setKnockoutMatches(updatedMatches);
  };

  const handleGenerateQuarters = () => {
     generateNextRound(
         ['match_1', 'match_2', 'match_3', 'match_4', 'match_5', 'match_6', 'match_7', 'match_8'],
         ['match_9', 'match_10', 'match_11', 'match_12']
     );
  };

  const handleGenerateSemis = () => {
      generateNextRound(
          ['match_9', 'match_10', 'match_11', 'match_12'],
          ['match_13', 'match_14']
      );
  };

  const handleGenerateFinal = () => {
      generateNextRound(
          ['match_13', 'match_14'],
          ['match_15']
      );
  };

  const handleUpdateKnockoutMatch = (matchId: string, score: string, winnerTeamId: string) => {
    if (!isAdmin) return;

    setKnockoutMatches(prev => {
        const updated = prev.map(m => {
            if (m.id === matchId) {
                return { ...m, score, winnerTeamId };
            }
            return m;
        });
        return updated;
    });
  };

  const handleUpdateTeamComposition = (teamId: string, p1: Player | null, p2: Player | null) => {
      setBracketTeams(prev => ({
          ...prev,
          [teamId]: { ...prev[teamId], player1: p1, player2: p2 }
      }));
  };

  return (
    <div className="min-h-screen pb-24 md:pb-10 font-sans text-gray-800">
      
      <RulesModal isOpen={isRulesModalOpen} onClose={() => setIsRulesModalOpen(false)} />
      <LoginModal isOpen={isLoginModalOpen} onClose={() => setIsLoginModalOpen(false)} onLogin={handleLogin} />

      {/* Header */}
      <nav className="bg-white sticky top-0 z-30 border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-shine-red flex items-center justify-center text-white font-bold">S</div>
              <span className="font-bold text-xl tracking-tight">SHINE <span className="text-shine-orange">PADEL</span></span>
            </div>
            
            {/* Desktop Tabs */}
            <div className="hidden md:flex space-x-6 h-full items-center">
               {[
                   { id: 'groups', label: 'Grupos' },
                   { id: 'bracket', label: 'Fase Final' },
                   { id: 'ranking', label: 'Ranking' },
                   { id: 'players', label: 'Jogadores' },
                   { id: 'schedule', label: 'Horários' },
               ].map((tab) => (
                 <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-full transition-colors ${
                      activeTab === tab.id 
                      ? 'border-shine-red text-gray-900' 
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                 >
                    {tab.label}
                 </button>
               ))}
            </div>

            {/* Admin Toggle */}
            <div className="flex items-center">
                <button 
                    onClick={() => isAdmin ? handleLogout() : setIsLoginModalOpen(true)}
                    className={`p-2 rounded-full transition-colors ${isAdmin ? 'text-shine-red bg-red-50' : 'text-gray-400 hover:text-gray-600'}`}
                    title={isAdmin ? "Modo Administrador (Clique para sair)" : "Acesso Admin"}
                >
                    {isAdmin ? <Unlock size={20} /> : <Lock size={20} />}
                </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Splash Info only on initial load / first tab */}
        {activeTab === 'groups' && (
          <Hero 
            onStart={() => document.getElementById('main-content')?.scrollIntoView({ behavior: 'smooth'})} 
            onOpenRules={() => setIsRulesModalOpen(true)}
          />
        )}

        <div id="main-content">
          {activeTab === 'groups' && (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              {/* Sidebar Group Selector */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 sticky top-24">
                  <h3 className="font-bold text-gray-500 uppercase text-xs mb-3">Selecionar Grupo</h3>
                  <div className="grid grid-cols-4 gap-2 lg:grid-cols-2">
                    {groups.map((g) => (
                      <button
                        key={g.id}
                        onClick={() => setSelectedGroup(g.id)}
                        className={`py-2 px-3 rounded-lg text-sm font-bold transition-all ${
                          selectedGroup === g.id 
                          ? 'bg-shine-red text-white shadow-md transform scale-105' 
                          : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        {g.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Group Detail */}
              <div className="lg:col-span-3">
                 {groups.length > 0 && (
                   <GroupView 
                     group={groups.find(g => g.id === selectedGroup)!} 
                     isAdmin={isAdmin}
                     onUpdateMatch={handleUpdateMatch}
                     onAddPlayer={handleAddPlayer}
                     onAddMatch={handleAddMatch}
                   />
                 )}
              </div>
            </div>
          )}

          {activeTab === 'bracket' && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 overflow-hidden">
               <div className="mb-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-l-4 border-shine-orange pl-4 mb-4">
                    <div>
                        <h2 className="text-2xl font-bold">Fase a Eliminar</h2>
                        <p className="text-gray-500 text-sm mt-1">
                            Duplas formadas pelo 1º Classificado de um grupo e o 2º Classificado de outro.
                        </p>
                    </div>
                  </div>
                  
                  {isAdmin && (
                      <div className="flex flex-wrap gap-2 bg-gray-50 p-3 rounded-lg border border-gray-200">
                          <span className="text-xs font-bold text-gray-500 w-full mb-1">Painel de Controlo Admin:</span>
                          <button 
                            onClick={handlePopulateBracket}
                            className="bg-shine-red text-white px-3 py-2 rounded-lg text-xs font-bold shadow hover:bg-red-700 transition-colors"
                          >
                              1. Gerar Oitavos
                          </button>
                          <button 
                            onClick={handleGenerateQuarters}
                            className="bg-white border border-gray-300 text-gray-700 px-3 py-2 rounded-lg text-xs font-bold hover:bg-gray-100 transition-colors"
                          >
                              2. Gerar Quartos
                          </button>
                          <button 
                            onClick={handleGenerateSemis}
                            className="bg-white border border-gray-300 text-gray-700 px-3 py-2 rounded-lg text-xs font-bold hover:bg-gray-100 transition-colors"
                          >
                              3. Gerar Meias
                          </button>
                          <button 
                            onClick={handleGenerateFinal}
                            className="bg-white border border-gray-300 text-gray-700 px-3 py-2 rounded-lg text-xs font-bold hover:bg-gray-100 transition-colors"
                          >
                              4. Gerar Final
                          </button>
                      </div>
                  )}
               </div>
               <BracketView 
                  matches={knockoutMatches} 
                  teams={bracketTeams} 
                  isAdmin={isAdmin}
                  onUpdateMatch={handleUpdateKnockoutMatch}
                  onUpdateTeam={handleUpdateTeamComposition}
               />
            </div>
          )}

          {activeTab === 'ranking' && (
              <RankingView groups={groups} />
          )}

          {activeTab === 'players' && (
              <PlayerListView groups={groups} isAdmin={isAdmin} />
          )}

          {activeTab === 'schedule' && (
            <div className="space-y-6">
               <div className="grid gap-6 md:grid-cols-2">
                 <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <Calendar className="text-shine-red" /> Horários
                    </h2>
                    <div className="space-y-4 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-gray-300 before:to-transparent">
                      {SCHEDULE.map((item, idx) => (
                        <div key={idx} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                           <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-50 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 text-xs font-bold text-shine-orange">
                             {idx + 1}
                           </div>
                           <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-gray-50 p-4 rounded-xl border border-gray-100 shadow-sm">
                              <div className="font-bold text-gray-900">{item.time}</div>
                              <div className="text-gray-600 text-sm">{item.event}</div>
                           </div>
                        </div>
                      ))}
                    </div>
                 </div>

                 <div id="rules" className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <BarChart3 className="text-shine-orange" /> Regras de Pontuação
                    </h2>
                    <div className="space-y-4">
                       {FUNNY_RULES.map((rule, idx) => (
                         <div key={idx} className="border-b border-gray-100 last:border-0 pb-4 last:pb-0">
                            <h4 className="font-bold text-gray-800 text-sm mb-1">{rule.title}</h4>
                            <p className="text-gray-600 text-sm italic">"{rule.content}"</p>
                         </div>
                       ))}
                    </div>
                    {isAdmin && (
                        <div className="mt-6 bg-red-50 p-4 rounded-lg text-xs text-red-800 border border-red-200">
                            <span className="font-bold block mb-1">Modo Administrador Ativo</span>
                            Você pode editar os resultados e equipas na Fase Final e Grupos.
                        </div>
                    )}
                 </div>
               </div>
            </div>
          )}
        </div>
      </main>

      {/* Mobile Tab Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 px-2 pb-safe pt-2">
        <div className="flex justify-between items-center text-[10px] font-medium">
           <button onClick={() => setActiveTab('groups')} className={`flex flex-1 flex-col items-center p-2 ${activeTab === 'groups' ? 'text-shine-red' : 'text-gray-400'}`}>
              <Users size={20} />
              <span className="mt-1">Grupos</span>
           </button>
           <button onClick={() => setActiveTab('ranking')} className={`flex flex-1 flex-col items-center p-2 ${activeTab === 'ranking' ? 'text-shine-red' : 'text-gray-400'}`}>
              <BarChart3 size={20} />
              <span className="mt-1">Rank</span>
           </button>
           <button onClick={() => setActiveTab('bracket')} className={`flex flex-1 flex-col items-center p-2 ${activeTab === 'bracket' ? 'text-shine-red' : 'text-gray-400'}`}>
              <Trophy size={20} />
              <span className="mt-1">Final</span>
           </button>
           <button onClick={() => setActiveTab('players')} className={`flex flex-1 flex-col items-center p-2 ${activeTab === 'players' ? 'text-shine-red' : 'text-gray-400'}`}>
              <List size={20} />
              <span className="mt-1">Jogadores</span>
           </button>
           <button onClick={() => setActiveTab('schedule')} className={`flex flex-1 flex-col items-center p-2 ${activeTab === 'schedule' ? 'text-shine-red' : 'text-gray-400'}`}>
              <Calendar size={20} />
              <span className="mt-1">Info</span>
           </button>
        </div>
      </div>

    </div>
  );
};

export default App;
