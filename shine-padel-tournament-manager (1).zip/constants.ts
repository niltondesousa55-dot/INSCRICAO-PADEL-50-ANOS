import { Group, Player, KnockoutMatch } from './types';

// Helper to create players
const p = (id: string, name: string, level: string, groupId: number): Player => ({
  id, name, level, groupId
});

// Initial Players Data extracted from PDF
// Group 1-16
export const INITIAL_GROUPS: Group[] = [
  {
    id: 1,
    name: "Grupo 1",
    players: [
      p("1-1", "ANTHONY CAVATI", "N4", 1),
      p("1-2", "EDER PINA", "N5", 1),
      p("1-3", "ALEXIS Nzoanene", "N6", 1),
      p("1-4", "ALMERINDA NAVAL", "N7", 1),
    ],
    matches: []
  },
  {
    id: 2,
    name: "Grupo 2",
    players: [
      p("2-1", "ZAMORA", "N4", 2),
      p("2-2", "ÉLCIO CARLOS", "N5", 2),
      p("2-3", "GIOVANNI ROSA", "N6", 2),
      p("2-4", "NEID SANTOS", "N7", 2),
    ],
    matches: []
  },
  {
    id: 3,
    name: "Grupo 3",
    players: [
      p("3-1", "MAURO LEANDRO", "N4", 3),
      p("3-2", "LUIS AMARAL", "N5", 3),
      p("3-3", "CINARA MAURICIO", "N6", 3),
      p("3-4", "QUENTIN RONGEAT", "N7", 3),
    ],
    matches: []
  },
  {
    id: 4,
    name: "Grupo 4",
    players: [
      p("4-1", "HRATCH", "N4", 4),
      p("4-2", "CATIA AMADO", "N5", 4),
      p("4-3", "TAYMIR Dos Santos", "N6", 4),
      p("4-4", "HUGO SÁ", "N7", 4),
    ],
    matches: []
  },
  {
    id: 5,
    name: "Grupo 5",
    players: [
      p("5-1", "Sir. ANTHONY SCP", "N4", 5),
      p("5-2", "FILIPE SILVEIRA", "N5", 5),
      p("5-3", "BRUNO CAETANO", "N6", 5),
      p("5-4", "OSCAR LETZ GUS", "N7", 5),
    ],
    matches: []
  },
  {
    id: 6,
    name: "Grupo 6",
    players: [
      p("6-1", "MARIO PALAGE", "N4", 6),
      p("6-2", "DARCY", "N5", 6),
      p("6-3", "KWAME SAÚDE", "N6", 6),
      p("6-4", "VASCO LOPES", "N7", 6),
    ],
    matches: []
  },
  {
    id: 7,
    name: "Grupo 7",
    players: [
      p("7-1", "IURI ANTONIO", "N4", 7),
      p("7-2", "NILTON SOUSA", "N5", 7),
      p("7-3", "JOAO SARDINHA", "N6", 7),
      p("7-4", "BRUNO VIEGAS", "N7", 7),
    ],
    matches: []
  },
  {
    id: 8,
    name: "Grupo 8",
    players: [
      p("8-1", "XANA", "N4", 8),
      p("8-2", "JOÃO REIS", "N5", 8),
      p("8-3", "KILLIAN", "N6", 8),
      p("8-4", "PEDRO CUNHA", "N7", 8),
    ],
    matches: []
  },
  {
    id: 9,
    name: "Grupo 9",
    players: [
      p("9-1", "NUNO SANTOS", "N4", 9),
      p("9-2", "KING MO", "N5", 9),
      p("9-3", "NUNO PEREIRA", "N6", 9),
      p("9-4", "BIBIANA", "N7", 9),
    ],
    matches: []
  },
  {
    id: 10,
    name: "Grupo 10",
    players: [
      p("10-1", "LUIS SENHORIO", "N4", 10),
      p("10-2", "JESSI SOARES", "N5", 10),
      p("10-3", "RUCA MOREIRA", "N6", 10),
      p("10-4", "ALINE SILVA", "N7", 10),
    ],
    matches: []
  },
  {
    id: 11,
    name: "Grupo 11",
    players: [
      p("11-1", "VICTOR CARDOSO", "N4", 11),
      p("11-2", "DANIILO PEDRO", "N5", 11),
      p("11-3", "PAULO EQUINET", "N6", 11),
      p("11-4", "MYLINE", "N7", 11),
    ],
    matches: []
  },
  {
    id: 12,
    name: "Grupo 12",
    players: [
      p("12-1", "ALEX CASA DE PADEL", "N4", 12),
      p("12-2", "YURI TEIXEIRA", "N5", 12),
      p("12-3", "KHAIA CORDEIRO", "N6", 12),
      p("12-4", "NELSON ALMEIDA", "N7", 12),
    ],
    matches: []
  },
  {
    id: 13,
    name: "Grupo 13",
    players: [
      p("13-1", "SR PIMENTA", "N4", 13),
      p("13-2", "MIGUEL CARVALHO", "N5", 13),
      p("13-3", "BRUNO MOREIRA", "N6", 13),
      p("13-4", "MICKAEL", "N7", 13),
    ],
    matches: []
  },
  {
    id: 14,
    name: "Grupo 14",
    players: [
      p("14-1", "VISSOLELA", "N4", 14),
      p("14-2", "IVAN SOEBORG", "N5", 14),
      p("14-3", "SIDRAQUE NETO", "N6", 14),
      p("14-4", "VANUZA VAN-DESTE", "N7", 14),
    ],
    matches: []
  },
  {
    id: 15,
    name: "Grupo 15",
    players: [
      p("15-1", "BRUNOX", "N4", 15),
      p("15-2", "VASCO AMARAL", "N5", 15),
      p("15-3", "RICARDO PIZZARRO", "N6", 15),
      p("15-4", "PAULO ARAÚJO", "N7", 15),
    ],
    matches: []
  },
  {
    id: 16,
    name: "Grupo 16",
    players: [
      p("16-1", "RICARDO GOMES", "N4", 16),
      p("16-2", "VALDEZ LEMOS", "N5", 16),
      p("16-3", "NUNO GODINHO", "N6", 16),
      p("16-4", "LORENA", "N7", 16),
    ],
    matches: []
  }
];

// Logic for Fixed Teams (Page 5 of PDF)
export const TEAM_COMPOSITIONS = [
  { id: 'A', g1: 1, pos1: 1, g2: 2, pos2: 2 }, // 1st G1 & 2nd G2
  { id: 'B', g1: 1, pos1: 2, g2: 2, pos2: 1 }, // 2nd G1 & 1st G2
  { id: 'C', g1: 3, pos1: 1, g2: 4, pos2: 2 },
  { id: 'D', g1: 3, pos1: 2, g2: 4, pos2: 1 },
  { id: 'E', g1: 5, pos1: 1, g2: 6, pos2: 2 },
  { id: 'F', g1: 5, pos1: 2, g2: 6, pos2: 1 },
  { id: 'G', g1: 7, pos1: 1, g2: 8, pos2: 2 },
  { id: 'H', g1: 7, pos1: 2, g2: 8, pos2: 1 },
  { id: 'I', g1: 9, pos1: 1, g2: 10, pos2: 2 },
  { id: 'J', g1: 9, pos1: 2, g2: 10, pos2: 1 },
  { id: 'K', g1: 11, pos1: 1, g2: 12, pos2: 2 },
  { id: 'L', g1: 11, pos1: 2, g2: 12, pos2: 1 },
  { id: 'M', g1: 13, pos1: 1, g2: 14, pos2: 2 },
  { id: 'N', g1: 13, pos1: 2, g2: 14, pos2: 1 },
  { id: 'O', g1: 15, pos1: 1, g2: 16, pos2: 2 },
  { id: 'P', g1: 15, pos1: 2, g2: 16, pos2: 1 },
];

export const INITIAL_KNOCKOUT_MATCHES: KnockoutMatch[] = [
  // Round of 16 (Oitavos)
  { id: 'match_1', round: 'round_of_16', teamAId: 'A', teamBId: 'B', score: null, winnerTeamId: null, nextMatchId: 'match_9' },
  { id: 'match_2', round: 'round_of_16', teamAId: 'C', teamBId: 'D', score: null, winnerTeamId: null, nextMatchId: 'match_9' },
  { id: 'match_3', round: 'round_of_16', teamAId: 'E', teamBId: 'F', score: null, winnerTeamId: null, nextMatchId: 'match_10' },
  { id: 'match_4', round: 'round_of_16', teamAId: 'G', teamBId: 'H', score: null, winnerTeamId: null, nextMatchId: 'match_10' },
  { id: 'match_5', round: 'round_of_16', teamAId: 'I', teamBId: 'J', score: null, winnerTeamId: null, nextMatchId: 'match_11' },
  { id: 'match_6', round: 'round_of_16', teamAId: 'K', teamBId: 'L', score: null, winnerTeamId: null, nextMatchId: 'match_11' },
  { id: 'match_7', round: 'round_of_16', teamAId: 'M', teamBId: 'N', score: null, winnerTeamId: null, nextMatchId: 'match_12' },
  { id: 'match_8', round: 'round_of_16', teamAId: 'O', teamBId: 'P', score: null, winnerTeamId: null, nextMatchId: 'match_12' },

  // Quarters
  { id: 'match_9', round: 'quarter_final', teamAId: 'TBD', teamBId: 'TBD', score: null, winnerTeamId: null, nextMatchId: 'match_13' }, // Winner 1 vs Winner 2
  { id: 'match_10', round: 'quarter_final', teamAId: 'TBD', teamBId: 'TBD', score: null, winnerTeamId: null, nextMatchId: 'match_13' }, // Winner 3 vs Winner 4
  { id: 'match_11', round: 'quarter_final', teamAId: 'TBD', teamBId: 'TBD', score: null, winnerTeamId: null, nextMatchId: 'match_14' }, // Winner 5 vs Winner 6
  { id: 'match_12', round: 'quarter_final', teamAId: 'TBD', teamBId: 'TBD', score: null, winnerTeamId: null, nextMatchId: 'match_14' }, // Winner 7 vs Winner 8

  // Semis
  { id: 'match_13', round: 'semi_final', teamAId: 'TBD', teamBId: 'TBD', score: null, winnerTeamId: null, nextMatchId: 'match_15' },
  { id: 'match_14', round: 'semi_final', teamAId: 'TBD', teamBId: 'TBD', score: null, winnerTeamId: null, nextMatchId: 'match_15' },

  // Final
  { id: 'match_15', round: 'final', teamAId: 'TBD', teamBId: 'TBD', score: null, winnerTeamId: null },
];

export const FUNNY_RULES = [
  { title: "Pontuação", content: "Vitória = 3 Pontos. Vitória em Tie Break = 2 Pontos. Derrota = 1 Ponto." },
  { title: "Empates", content: "Os jogos não podem terminar empatados. Em caso de empate joga-se mini tie break até aos 5 pontos." },
  { title: "Critério de Desempate", content: "1º Pontos. 2º Diferença de Jogos. 3º Vontade do Baixinho sem direito a recurso." },
  { title: "Duração de Jogos (Fase Grupos)", content: "15 min + 5 min aquecimento. Cuidado com o óleo de escorpião do Nuno." },
  { title: "Bálsamos", content: "Para os mais cansados podem pedir ao baixinho que coloque o bálsamo e faça uma massagem. Excepções falem no Off." }
];

export const SCHEDULE = [
  { time: "08:00 - 09:00", event: "Fase de Grupos (G1 a G6)" },
  { time: "10:15 - 11:15", event: "Fase de Grupos (G7 a G12)" },
  { time: "11:30 - 12:30", event: "Fase de Grupos (G13 a G16)" },
  { time: "14:30 - 15:00", event: "Oitavos de Final (Jogos 1 a 4)" },
  { time: "15:00 - 15:30", event: "Oitavos de Final (Jogos 5 a 8)" },
  { time: "16:00 - 16:30", event: "Quartos de Final (Jogos 9 e 10)" },
  { time: "16:45 - 17:15", event: "Quartos de Final (Jogos 11 e 12)" },
  { time: "17:30 - 18:00", event: "Meia Final (Jogo 13)" },
  { time: "18:15 - 18:45", event: "Meia Final (Jogo 14)" },
  { time: "19:15", event: "Grande Final (Jogo 15)" },
];