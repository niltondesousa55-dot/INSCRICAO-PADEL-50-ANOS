
import React, { useState } from 'react';
import { Group, GroupMatch, Standing, Player } from '../types';
import { Save, AlertCircle, Plus, X, Lock } from 'lucide-react';

interface GroupViewProps {
  group: Group;
  isAdmin: boolean;
  onUpdateMatch: (groupId: number, match: GroupMatch) => void;
  onAddPlayer: (groupId: number, name: string, level: string) => void;
  onAddMatch: (groupId: number) => void;
}

const GroupView: React.FC<GroupViewProps> = ({ group, isAdmin, onUpdateMatch, onAddPlayer, onAddMatch }) => {
  const [editingMatch, setEditingMatch] = useState<string | null>(null);
  
  // Changed from number inputs to a single string input
  const [scoreInput, setScoreInput] = useState<string>('');
  const [tieBreakWin, setTieBreakWin] = useState<boolean>(false);
  
  // Add Player State
  const [isAddingPlayer, setIsAddingPlayer] = useState(false);
  const [newPlayerName, setNewPlayerName] = useState('');
  const [newPlayerLevel, setNewPlayerLevel] = useState('N6');

  // Calculate Standings Logic (2v2 Americano)
  const calculateStandings = (players: Player[], matches: GroupMatch[]): (Standing & { tieBreakWins: number })[] => {
    const standings: Record<string, Standing & { tieBreakWins: number }> = {};
    
    // Initialize
    players.forEach(p => {
      standings[p.id] = {
        playerId: p.id,
        points: 0,
        played: 0,
        won: 0,
        lost: 0,
        gamesWon: 0,
        gamesLost: 0,
        diff: 0,
        tieBreakWins: 0
      };
    });

    matches.forEach(m => {
      if (m.status === 'finished' && m.result) {
        const { scoreA, scoreB, isTieBreakWin } = m.result;
        
        // Helper to update pair stats
        const updatePair = (pIds: string[], myScore: number, oppScore: number, isWinner: boolean) => {
            pIds.forEach(id => {
                const s = standings[id];
                if (s) {
                    s.played += 1;
                    s.gamesWon += myScore;
                    s.gamesLost += oppScore;
                    s.diff += (myScore - oppScore);
                    if (isWinner) {
                         if (isTieBreakWin) {
                            s.tieBreakWins += 1;
                            s.points += 2;
                         } else {
                            s.won += 1;
                            s.points += 3;
                         }
                    } else {
                        if (myScore === oppScore) { // Draw
                           s.points += 1;
                        } else {
                           s.lost += 1;
                           s.points += 1;
                        }
                    }
                }
            });
        };

        const teamA = [m.player1Id, m.player2Id];
        const teamB = [m.player3Id, m.player4Id];

        if (scoreA > scoreB) {
            updatePair(teamA, scoreA, scoreB, true);
            updatePair(teamB, scoreB, scoreA, false);
        } else if (scoreB > scoreA) {
            updatePair(teamA, scoreA, scoreB, false);
            updatePair(teamB, scoreB, scoreA, true);
        } else {
            // Draw
             updatePair(teamA, scoreA, scoreB, false);
             updatePair(teamB, scoreB, scoreA, false);
        }
      }
    });

    return Object.values(standings).sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.diff !== a.diff) return b.diff - a.diff;
      return b.gamesWon - a.gamesWon;
    });
  };

  const standings = calculateStandings(group.players, group.matches);

  const parseScore = (input: string) => {
    // Allows "6-4", "6/4", "6 4", "6-4 6-2"
    // Split by space or comma to find sets
    const sets = input.trim().split(/[\s,]+/);
    let totalA = 0;
    let totalB = 0;

    sets.forEach(set => {
       // Split by - or / or : to find games in set
       const games = set.split(/[-/:]/);
       if (games.length === 2) {
         const gA = parseInt(games[0]);
         const gB = parseInt(games[1]);
         if (!isNaN(gA)) totalA += gA;
         if (!isNaN(gB)) totalB += gB;
       }
    });

    return { totalA, totalB };
  };

  const handleSaveScore = (match: GroupMatch) => {
    if (!scoreInput.trim()) return;

    // Calculate total games for ranking purposes
    const { totalA, totalB } = parseScore(scoreInput);

    onUpdateMatch(group.id, {
      ...match,
      status: 'finished',
      result: {
        scoreA: totalA,
        scoreB: totalB,
        displayScore: scoreInput, // Save the text representation
        isTieBreakWin: tieBreakWin
      }
    });
    setEditingMatch(null);
    setScoreInput('');
    setTieBreakWin(false);
  };

  const handleAddPlayerSubmit = () => {
    if (!newPlayerName.trim()) return;
    onAddPlayer(group.id, newPlayerName, newPlayerLevel);
    setNewPlayerName('');
    setNewPlayerLevel('N6');
    setIsAddingPlayer(false);
  };

  const startEdit = (match: GroupMatch) => {
    setEditingMatch(match.id);
    if (match.result) {
      // Use stored display string, or reconstruct it if missing
      setScoreInput(match.result.displayScore || `${match.result.scoreA}-${match.result.scoreB}`);
      setTieBreakWin(match.result.isTieBreakWin || false);
    } else {
      setScoreInput('');
      setTieBreakWin(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Standings Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex justify-between items-center">
          <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
            Classificação - {group.name}
          </h3>
          {isAdmin && (
            <button 
              onClick={() => setIsAddingPlayer(!isAddingPlayer)}
              className={`flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-full transition-colors ${isAddingPlayer ? 'bg-gray-200 text-gray-600' : 'bg-shine-red text-white hover:bg-red-700'}`}
            >
              {isAddingPlayer ? <X size={14} /> : <Plus size={14} />}
              <span className="hidden sm:inline">{isAddingPlayer ? 'Cancelar' : 'Adicionar Jogador'}</span>
            </button>
          )}
        </div>

        {/* Add Player Form */}
        {isAddingPlayer && isAdmin && (
          <div className="bg-orange-50 p-4 border-b border-orange-100 animate-in fade-in slide-in-from-top-2">
            <h4 className="text-xs font-bold text-orange-800 uppercase mb-3">Novo Jogador</h4>
            <div className="flex flex-col sm:flex-row gap-4 items-end">
              <div className="flex-1 w-full">
                <label className="block text-xs font-bold text-gray-500 mb-1">Nome</label>
                <input 
                  type="text"
                  value={newPlayerName}
                  onChange={(e) => setNewPlayerName(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-shine-orange focus:border-transparent"
                  placeholder="Ex: João Silva"
                />
              </div>
              <div className="w-full sm:w-32">
                <label className="block text-xs font-bold text-gray-500 mb-1">Nível</label>
                <select 
                  value={newPlayerLevel}
                  onChange={(e) => setNewPlayerLevel(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-shine-orange focus:border-transparent"
                >
                  <option value="N4">N4</option>
                  <option value="N5">N5</option>
                  <option value="N6">N6</option>
                  <option value="N7">N7</option>
                </select>
              </div>
              <button 
                onClick={handleAddPlayerSubmit}
                disabled={!newPlayerName.trim()}
                className="w-full sm:w-auto bg-shine-orange text-white font-bold py-2 px-6 rounded-lg hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Adicionar
              </button>
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-50 text-gray-500 uppercase font-medium text-xs">
              <tr>
                <th className="px-6 py-3 w-10">#</th>
                <th className="px-6 py-3">Jogador</th>
                <th className="px-6 py-3 text-center">PTS</th>
                <th className="px-6 py-3 text-center hidden sm:table-cell">J</th>
                <th className="px-6 py-3 text-center hidden sm:table-cell">V</th>
                <th className="px-6 py-3 text-center hidden sm:table-cell" title="Empates / Tie Break Win">E</th>
                <th className="px-6 py-3 text-center hidden sm:table-cell">D</th>
                <th className="px-6 py-3 text-center">Dif</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {standings.map((s, idx) => {
                const player = group.players.find(p => p.id === s.playerId);
                const isQualifying = idx < 2; // Top 2 qualify
                return (
                  <tr key={s.playerId} className={`hover:bg-gray-50 ${isQualifying ? 'bg-orange-50/30' : ''}`}>
                    <td className="px-6 py-4 font-bold text-gray-400">
                      <span className={`flex items-center justify-center w-6 h-6 rounded-full ${isQualifying ? 'bg-shine-orange text-white' : ''}`}>
                        {idx + 1}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-medium text-gray-900">
                      {player?.name}
                      <span className="ml-2 text-xs text-gray-400 border border-gray-200 px-1 rounded">
                        {player?.level}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center font-bold text-shine-red">{s.points}</td>
                    <td className="px-6 py-4 text-center text-gray-600 hidden sm:table-cell">{s.played}</td>
                    <td className="px-6 py-4 text-center text-green-600 hidden sm:table-cell">{s.won}</td>
                    <td className="px-6 py-4 text-center text-yellow-600 hidden sm:table-cell">{s.tieBreakWins}</td>
                    <td className="px-6 py-4 text-center text-red-400 hidden sm:table-cell">{s.lost}</td>
                    <td className="px-6 py-4 text-center font-mono text-gray-600">
                      {s.diff > 0 ? '+' : ''}{s.diff}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Matches List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-gray-800">Jogos (Duplas)</h3>
          {isAdmin && (
            <button 
              onClick={() => onAddMatch(group.id)}
              className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-full bg-shine-red text-white hover:bg-red-700 transition-colors"
            >
              <Plus size={14} /> Adicionar Jogo
            </button>
          )}
        </div>
        
        <div className="grid gap-4 md:grid-cols-2">
          {group.matches.map((match) => {
            const p1 = group.players.find(p => p.id === match.player1Id);
            const p2 = group.players.find(p => p.id === match.player2Id);
            const p3 = group.players.find(p => p.id === match.player3Id);
            const p4 = group.players.find(p => p.id === match.player4Id);
            
            const isEditing = editingMatch === match.id;

            return (
              <div key={match.id} className="border border-gray-200 rounded-lg p-4 hover:border-shine-orange transition-colors">
                <div className="flex justify-between items-center mb-2">
                  <div className="text-xs font-bold text-gray-400 uppercase tracking-wide">
                    {match.status === 'finished' ? 'Finalizado' : 'Agendado'}
                  </div>
                  {!isEditing && isAdmin && (
                    <button 
                      onClick={() => startEdit(match)}
                      className="text-xs text-shine-red hover:underline font-medium"
                    >
                      {match.status === 'finished' ? 'Corrigir' : 'Lançar'}
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between gap-2">
                  {/* Team A */}
                  <div className={`flex-1 text-right flex flex-col justify-center ${match.result && match.result.scoreA > match.result.scoreB ? 'font-bold text-gray-900' : 'text-gray-600'}`}>
                    <span className="text-xs sm:text-sm">{p1?.name || '?'}</span>
                    <span className="text-[10px] sm:text-xs text-gray-400">&</span>
                    <span className="text-xs sm:text-sm">{p2?.name || '?'}</span>
                  </div>

                  {/* Score Area */}
                  <div className="flex items-center gap-2 justify-center min-w-[5rem]">
                    {isEditing ? (
                        <input 
                          type="text" 
                          className="w-20 h-8 text-center border border-shine-orange rounded bg-white text-sm font-bold"
                          placeholder="6-4"
                          autoFocus
                          value={scoreInput}
                          onChange={(e) => setScoreInput(e.target.value)}
                        />
                    ) : (
                      <div className="px-3 py-1 bg-gray-100 rounded-md font-mono font-bold text-lg text-center whitespace-nowrap">
                        {match.result ? (match.result.displayScore || `${match.result.scoreA}-${match.result.scoreB}`) : 'vs'}
                      </div>
                    )}
                  </div>

                  {/* Team B */}
                  <div className={`flex-1 text-left flex flex-col justify-center ${match.result && match.result.scoreB > match.result.scoreA ? 'font-bold text-gray-900' : 'text-gray-600'}`}>
                    <span className="text-xs sm:text-sm">{p3?.name || '?'}</span>
                    <span className="text-[10px] sm:text-xs text-gray-400">&</span>
                    <span className="text-xs sm:text-sm">{p4?.name || '?'}</span>
                  </div>
                </div>
                
                {isEditing && (
                   <div className="mt-3 bg-gray-50 p-2 rounded flex flex-col gap-2">
                      <div className="text-[10px] text-gray-400 text-center">Ex: "6-4" ou "6-3 6-2"</div>
                      <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer select-none justify-center">
                        <input 
                          type="checkbox" 
                          checked={tieBreakWin}
                          onChange={(e) => setTieBreakWin(e.target.checked)}
                          className="rounded text-shine-red focus:ring-shine-orange"
                        />
                        Vitória por Tie-Break? (2 pts)
                      </label>
                      <button
                        onClick={() => handleSaveScore(match)}
                        className="w-full flex items-center justify-center gap-2 bg-shine-orange text-white text-xs font-bold py-2 rounded hover:bg-orange-600"
                      >
                        <Save className="w-3 h-3" /> Salvar Resultado
                      </button>
                   </div>
                )}
                 
                 {match.result?.isTieBreakWin && !isEditing && (
                   <div className="text-center mt-1">
                      <span className="text-[10px] bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full">Tie Break</span>
                   </div>
                 )}

              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default GroupView;
