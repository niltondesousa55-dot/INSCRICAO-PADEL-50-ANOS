import React, { useState } from 'react';
import { KnockoutMatch, KnockoutTeam, Player } from '../types';
import { Edit2, CheckCircle } from 'lucide-react';

interface BracketViewProps {
  matches: KnockoutMatch[];
  teams: Record<string, KnockoutTeam>;
  isAdmin: boolean;
  onUpdateMatch: (matchId: string, score: string, winnerTeamId: string) => void;
  onUpdateTeam: (teamId: string, p1: Player | null, p2: Player | null) => void;
}

const BracketView: React.FC<BracketViewProps> = ({ matches, teams, isAdmin, onUpdateMatch, onUpdateTeam }) => {
  const [editingMatchId, setEditingMatchId] = useState<string | null>(null);
  const [matchScore, setMatchScore] = useState('');
  const [matchWinner, setMatchWinner] = useState('');

  const [editingTeamId, setEditingTeamId] = useState<string | null>(null);
  const [editP1Name, setEditP1Name] = useState('');
  const [editP2Name, setEditP2Name] = useState('');

  const rounds = [
    { id: 'round_of_16', label: 'Oitavos', matches: matches.filter(m => m.round === 'round_of_16') },
    { id: 'quarter_final', label: 'Quartos', matches: matches.filter(m => m.round === 'quarter_final') },
    { id: 'semi_final', label: 'Meias', matches: matches.filter(m => m.round === 'semi_final') },
    { id: 'final', label: 'Final', matches: matches.filter(m => m.round === 'final') },
  ];

  const handleSaveMatch = (matchId: string) => {
      if(matchWinner) {
          onUpdateMatch(matchId, matchScore, matchWinner);
          setEditingMatchId(null);
          setMatchScore('');
          setMatchWinner('');
      }
  };

  const handleStartEditTeam = (team: KnockoutTeam) => {
      setEditingTeamId(team.id);
      setEditP1Name(team.player1?.name || '');
      setEditP2Name(team.player2?.name || '');
  };

  const handleSaveTeam = () => {
      if(editingTeamId) {
          const t = teams[editingTeamId];
          const p1 = t.player1 ? { ...t.player1, name: editP1Name } : { id: 'manual-p1', name: editP1Name, level: '', groupId: 0 };
          const p2 = t.player2 ? { ...t.player2, name: editP2Name } : { id: 'manual-p2', name: editP2Name, level: '', groupId: 0 };
          
          onUpdateTeam(editingTeamId, p1, p2);
          setEditingTeamId(null);
      }
  };

  return (
    <div className="overflow-x-auto pb-8">
      
      {/* Team Edit Modal */}
      {editingTeamId && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-sm">
                  <h3 className="font-bold text-lg mb-4">Editar Equipa {editingTeamId}</h3>
                  <div className="space-y-4">
                      <div>
                          <label className="block text-xs font-bold text-gray-500 mb-1">Jogador 1</label>
                          <input 
                              value={editP1Name}
                              onChange={e => setEditP1Name(e.target.value)}
                              className="w-full border rounded p-2 text-sm"
                          />
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-gray-500 mb-1">Jogador 2</label>
                          <input 
                              value={editP2Name}
                              onChange={e => setEditP2Name(e.target.value)}
                              className="w-full border rounded p-2 text-sm"
                          />
                      </div>
                      <div className="flex gap-2 justify-end mt-4">
                          <button onClick={() => setEditingTeamId(null)} className="px-4 py-2 text-gray-600 text-sm">Cancelar</button>
                          <button onClick={handleSaveTeam} className="px-4 py-2 bg-shine-red text-white rounded text-sm font-bold">Salvar</button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      <div className="min-w-[1000px] flex justify-between gap-8 px-4">
        {rounds.map((round) => (
          <div key={round.id} className="flex-1 flex flex-col justify-around">
            <h3 className="text-center font-bold text-shine-red uppercase tracking-wider mb-6">{round.label}</h3>
            <div className="flex flex-col justify-around h-full gap-8">
              {round.matches.map((match) => {
                const teamA = match.teamAId !== 'TBD' ? teams[match.teamAId] : null;
                const teamB = match.teamBId !== 'TBD' ? teams[match.teamBId] : null;
                const isEditing = editingMatchId === match.id;
                
                return (
                  <div key={match.id} className="relative bg-white border border-gray-200 rounded-lg shadow-sm w-full group">
                    {/* Admin Edit Controls */}
                    {isAdmin && !isEditing && (teamA || teamB) && (
                        <div className="absolute -top-3 -right-3 z-10 hidden group-hover:block">
                            <button 
                                onClick={() => {
                                    setEditingMatchId(match.id);
                                    setMatchScore(match.score || '');
                                    setMatchWinner(match.winnerTeamId || '');
                                }}
                                className="bg-white border border-gray-200 shadow-sm p-1.5 rounded-full hover:text-shine-orange text-gray-400"
                            >
                                <Edit2 size={12} />
                            </button>
                        </div>
                    )}

                    {/* Team A */}
                    <div className={`p-3 border-b border-gray-100 flex justify-between items-center ${match.winnerTeamId === match.teamAId ? 'bg-orange-50' : ''}`}>
                       <div className="flex flex-col">
                          <div className="flex items-center gap-2">
                             <span className={`text-xs font-bold ${match.winnerTeamId === match.teamAId ? 'text-shine-orange' : 'text-gray-400'}`}>
                                {match.teamAId === 'TBD' ? 'A Definir' : `Equipa ${teamA?.id}`}
                             </span>
                             {isAdmin && teamA && (
                                 <button onClick={() => handleStartEditTeam(teamA)} className="text-[10px] text-gray-300 hover:text-shine-red"><Edit2 size={8}/></button>
                             )}
                          </div>
                          {teamA && (
                             <span className="text-[10px] text-gray-500 leading-tight">
                               {teamA.player1 ? teamA.player1.name : `${teamA.pos1}º G${teamA.g1}`} & {teamA.player2 ? teamA.player2.name : `${teamA.pos2}º G${teamA.g2}`}
                             </span>
                          )}
                       </div>
                    </div>
                    
                    {/* Team B */}
                    <div className={`p-3 flex justify-between items-center ${match.winnerTeamId === match.teamBId ? 'bg-orange-50' : ''}`}>
                        <div className="flex flex-col">
                           <div className="flex items-center gap-2">
                              <span className={`text-xs font-bold ${match.winnerTeamId === match.teamBId ? 'text-shine-orange' : 'text-gray-400'}`}>
                                 {match.teamBId === 'TBD' ? 'A Definir' : `Equipa ${teamB?.id}`}
                              </span>
                              {isAdmin && teamB && (
                                 <button onClick={() => handleStartEditTeam(teamB)} className="text-[10px] text-gray-300 hover:text-shine-red"><Edit2 size={8}/></button>
                             )}
                           </div>
                           {teamB && (
                             <span className="text-[10px] text-gray-500 leading-tight">
                               {teamB.player1 ? teamB.player1.name : `${teamB.pos1}º G${teamB.g1}`} & {teamB.player2 ? teamB.player2.name : `${teamB.pos2}º G${teamB.g2}`}
                             </span>
                          )}
                       </div>
                    </div>

                    {match.score && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 bg-gray-100 px-2 py-1 rounded text-xs font-bold border border-gray-200">
                            {match.score}
                        </div>
                    )}

                    {/* Editor Overlay */}
                    {isEditing && (
                        <div className="absolute inset-0 bg-white/95 z-20 flex flex-col items-center justify-center p-4 text-center rounded-lg">
                            <h4 className="text-xs font-bold mb-2">Resultado</h4>
                            <input 
                                type="text" 
                                placeholder="Ex: 6-4, 6-2"
                                value={matchScore}
                                onChange={e => setMatchScore(e.target.value)}
                                className="w-full text-center border border-gray-300 rounded mb-2 text-sm p-1"
                            />
                            <div className="flex gap-2 w-full mb-2">
                                <button 
                                   onClick={() => setMatchWinner(match.teamAId)}
                                   className={`flex-1 py-1 text-[10px] border rounded ${matchWinner === match.teamAId ? 'bg-shine-orange text-white border-shine-orange' : 'bg-white text-gray-500'}`}
                                >
                                    Vence A
                                </button>
                                <button 
                                   onClick={() => setMatchWinner(match.teamBId)}
                                   className={`flex-1 py-1 text-[10px] border rounded ${matchWinner === match.teamBId ? 'bg-shine-orange text-white border-shine-orange' : 'bg-white text-gray-500'}`}
                                >
                                    Vence B
                                </button>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={() => setEditingMatchId(null)} className="text-xs text-gray-400 underline">Cancelar</button>
                                <button onClick={() => handleSaveMatch(match.id)} className="text-xs font-bold text-green-600 flex items-center gap-1">
                                    <CheckCircle size={12}/> Salvar
                                </button>
                            </div>
                        </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BracketView;