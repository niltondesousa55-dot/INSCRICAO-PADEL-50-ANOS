import React from 'react';
import { Group, Player, Standing } from '../types';
import { Trophy } from 'lucide-react';

interface RankingViewProps {
  groups: Group[];
}

interface GlobalStanding extends Standing {
  tieBreakWins: number;
  playerName: string;
  groupName: string;
  level: string;
}

const RankingView: React.FC<RankingViewProps> = ({ groups }) => {
  
  const getGlobalStandings = (): GlobalStanding[] => {
    const allStandings: GlobalStanding[] = [];

    groups.forEach(group => {
        // Initialize local stats for this group's players
        const groupStats: Record<string, GlobalStanding> = {};
        
        group.players.forEach(p => {
            groupStats[p.id] = {
                playerId: p.id,
                playerName: p.name,
                groupName: group.name,
                level: p.level,
                points: 0,
                played: 0,
                won: 0,
                tieBreakWins: 0,
                lost: 0,
                gamesWon: 0,
                gamesLost: 0,
                diff: 0
            };
        });

        group.matches.forEach(m => {
            if (m.status === 'finished' && m.result) {
                const { scoreA, scoreB, isTieBreakWin } = m.result;
                
                const teamA = [m.player1Id, m.player2Id];
                const teamB = [m.player3Id, m.player4Id];

                const processTeam = (pIds: string[], myScore: number, oppScore: number, isWinner: boolean) => {
                    pIds.forEach(pid => {
                        const p = groupStats[pid];
                        if (!p) return;
                        
                        p.played++;
                        p.gamesWon += myScore;
                        p.gamesLost += oppScore;
                        p.diff += (myScore - oppScore);

                        if (isWinner) {
                            if (isTieBreakWin) {
                                p.tieBreakWins++;
                                p.points += 2;
                            } else {
                                p.won++;
                                p.points += 3;
                            }
                        } else {
                            if (myScore === oppScore) {
                                // Draw
                                p.points += 1; 
                            } else {
                                p.lost++;
                                p.points += 1;
                            }
                        }
                    });
                };

                if (scoreA > scoreB) {
                    processTeam(teamA, scoreA, scoreB, true);
                    processTeam(teamB, scoreB, scoreA, false);
                } else if (scoreB > scoreA) {
                    processTeam(teamA, scoreA, scoreB, false);
                    processTeam(teamB, scoreB, scoreA, true);
                } else {
                    processTeam(teamA, scoreA, scoreB, false);
                    processTeam(teamB, scoreB, scoreA, false);
                }
            }
        });
        
        // Push this group's players to main array
        Object.values(groupStats).forEach(s => allStandings.push(s));
    });

    // Global Sort
    return allStandings.sort((a, b) => {
        if (b.points !== a.points) return b.points - a.points;
        if (b.diff !== a.diff) return b.diff - a.diff;
        return b.gamesWon - a.gamesWon;
    });
  };

  const standings = getGlobalStandings();

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex items-center gap-3">
            <Trophy className="text-shine-orange w-5 h-5" />
            <h3 className="text-lg font-bold text-gray-800">Ranking Global</h3>
        </div>
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-gray-500 uppercase font-medium text-xs">
                    <tr>
                        <th className="px-6 py-3 w-12">#</th>
                        <th className="px-6 py-3">Jogador</th>
                        <th className="px-6 py-3">Grupo</th>
                        <th className="px-6 py-3 text-center bg-gray-100">PTS</th>
                        <th className="px-6 py-3 text-center">Jogos</th>
                        <th className="px-6 py-3 text-center text-green-600" title="Vitórias (3 pts)">Vitórias</th>
                        <th className="px-6 py-3 text-center text-yellow-600" title="Empates / Tie Break (2 pts)">Empates</th>
                        <th className="px-6 py-3 text-center text-red-500" title="Derrotas (1 pt)">Derrotas</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {standings.map((s, idx) => (
                        <tr key={`${s.groupName}-${s.playerId}`} className="hover:bg-gray-50">
                             <td className="px-6 py-4 font-bold text-gray-400">
                                {idx + 1}
                             </td>
                             <td className="px-6 py-4 font-medium text-gray-900">
                                {s.playerName}
                                <span className="ml-2 text-[10px] text-gray-500 border border-gray-200 px-1 rounded bg-white">
                                    {s.level}
                                </span>
                             </td>
                             <td className="px-6 py-4 text-gray-500 text-xs">
                                {s.groupName}
                             </td>
                             <td className="px-6 py-4 text-center font-bold text-shine-red bg-gray-50">
                                {s.points}
                             </td>
                             <td className="px-6 py-4 text-center text-gray-600">
                                {s.played}
                             </td>
                             <td className="px-6 py-4 text-center font-medium text-green-700">
                                {s.won}
                             </td>
                             <td className="px-6 py-4 text-center font-medium text-yellow-600">
                                {s.tieBreakWins}
                             </td>
                             <td className="px-6 py-4 text-center text-red-400">
                                {s.lost}
                             </td>
                        </tr>
                    ))}
                    {standings.length === 0 && (
                        <tr>
                            <td colSpan={8} className="px-6 py-8 text-center text-gray-400">
                                Ainda não existem dados para o ranking.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    </div>
  );
};

export default RankingView;