import React from 'react';
import { Trophy, Info } from 'lucide-react';

interface HeroProps {
  onStart: () => void;
  onOpenRules: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStart, onOpenRules }) => {
  return (
    <div className="relative overflow-hidden bg-white shadow-lg rounded-2xl mb-6">
      <div className="absolute top-0 right-0 w-64 h-64 bg-shine-orange opacity-10 rounded-full translate-x-1/3 -translate-y-1/3 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-shine-red opacity-10 rounded-full -translate-x-1/3 translate-y-1/3 blur-3xl"></div>
      
      <div className="relative z-10 p-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="text-center md:text-left flex-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100 text-shine-orange rounded-full text-xs font-bold uppercase tracking-wider mb-4">
            <Trophy className="w-4 h-4" />
            1º Torneio Shine Padel
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight mb-4">
            SHINE <span className="shine-text-gradient">PADEL</span> LUANDA
          </h1>
          <p className="text-gray-600 text-lg max-w-md mb-6">
            Onde as regras são para cumprir... qb. Bem-vindos ao torneio mais polémico e divertido de Luanda.
          </p>
          <div className="flex flex-wrap gap-3 justify-center md:justify-start">
            <button 
              onClick={onStart}
              className="bg-shine-red hover:bg-red-700 text-white font-bold py-3 px-6 rounded-xl transition-all shadow-md transform hover:-translate-y-1"
            >
              Ver Classificações
            </button>
            <button 
              onClick={onOpenRules}
              className="bg-white border-2 border-gray-200 hover:border-shine-orange text-gray-700 font-bold py-3 px-6 rounded-xl transition-all"
            >
              <span className="flex items-center gap-2">
                <Info className="w-5 h-5" />
                Regras do Baixinho
              </span>
            </button>
          </div>
        </div>

        <div className="w-full md:w-auto flex justify-center md:justify-end">
           {/* Custom SVG Logo Recreation */}
           <div className="w-64 h-64 md:w-80 md:h-80 relative filter drop-shadow-xl hover:scale-105 transition-transform duration-300">
             <svg viewBox="0 0 500 400" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="racketDots" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                    <circle cx="10" cy="10" r="3" fill="#1a1a1a" opacity="0.6" />
                  </pattern>
                </defs>
                
                {/* Racket Head Group */}
                <g transform="translate(250, 150)">
                   {/* Handle/Neck hint */}
                   <rect x="-15" y="80" width="30" height="60" fill="#ED1C24" stroke="#1a1a1a" strokeWidth="4" />
                   
                   {/* Main Circle */}
                   <circle cx="0" cy="0" r="100" fill="#ED1C24" stroke="#1a1a1a" strokeWidth="6" />
                   
                   {/* Inner Rim/Detail */}
                   <circle cx="0" cy="0" r="90" fill="none" stroke="#B91C1C" strokeWidth="2" />
                   
                   {/* Dots Texture */}
                   <circle cx="0" cy="0" r="85" fill="url(#racketDots)" />
                </g>

                {/* Text Group - Using multiple layers for stroke effect */}
                <g transform="translate(250, 240)">
                   {/* Thick Outline */}
                   <text x="0" y="0" textAnchor="middle" fontFamily="Impact, sans-serif" fontSize="95" fill="none" stroke="#1a1a1a" strokeWidth="16" strokeLinejoin="round">SHINE PADEL</text>
                   
                   {/* Inner Fill */}
                   <text x="0" y="0" textAnchor="middle" fontFamily="Impact, sans-serif" fontSize="95" fill="#FDB913">SHINE PADEL</text>
                </g>

                {/* Ribbon Group */}
                <g transform="translate(250, 260)">
                   {/* Ribbon Back/Shadow Parts */}
                   <path d="M -130 10 L -140 -10 L -110 10 Z" fill="#991B1B" />
                   <path d="M 130 10 L 140 -10 L 110 10 Z" fill="#991B1B" />

                   {/* Main Ribbon Banner */}
                   <path d="M -110 15 L -130 50 L 130 50 L 110 15 L 0 25 Z" fill="#ED1C24" stroke="#1a1a1a" strokeWidth="4" />
                   
                   {/* Ribbon Tails */}
                   <path d="M -110 15 L -130 50 L -110 50 L -100 25 Z" fill="#B91C1C" /> 
                   <path d="M 110 15 L 130 50 L 110 50 L 100 25 Z" fill="#B91C1C" />
                   
                   {/* Ribbon Text */}
                   <text x="0" y="42" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="bold" fontSize="24" fill="#1a1a1a" letterSpacing="4">LUANDA</text>
                </g>
             </svg>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
