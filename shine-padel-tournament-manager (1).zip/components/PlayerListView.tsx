import React, { useState } from 'react';
import { Group } from '../types';
import { Users, Search, Filter } from 'lucide-react';

interface PlayerListViewProps {
  groups: Group[];
  isAdmin: boolean;
}

const PlayerListView: React.FC<PlayerListViewProps> = ({ groups, isAdmin }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState('TODOS');

  const allPlayers = groups.flatMap(g => 
    g.players.map(p => ({ ...p, groupName: g.name }))
  );

  const filteredPlayers = allPlayers.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.groupName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLevel = levelFilter === 'TODOS' || p.level === levelFilter;
    
    return matchesSearch && matchesLevel;
  });

  const levels = ['TODOS', 'N4', 'N5', 'N6', 'N7'];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex flex-col gap-6 mb-6">
        
        {/* Header and Search */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
                <Users className="text-shine-red" />
                Jogadores Inscritos
                <span className="text-sm font-normal text-gray-500 ml-2">({allPlayers.length})</span>
            </h2>
            <div className="relative w-full md:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input 
                    type="text" 
                    placeholder="Pesquisar jogador..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-shine-orange/20 focus:border-shine-orange"
                />
            </div>
        </div>

        {/* Level Filters */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
             <div className="flex items-center gap-2 text-sm font-bold text-gray-500">
                <Filter size={16} />
                <span>Filtrar por Nível:</span>
             </div>
             <div className="flex flex-wrap gap-2">
                 {levels.map(lvl => (
                     <button
                        key={lvl}
                        onClick={() => setLevelFilter(lvl)}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                            levelFilter === lvl
                            ? 'bg-shine-orange text-white shadow-md transform scale-105'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                     >
                        {lvl === 'TODOS' ? 'Todos' : lvl}
                     </button>
                 ))}
             </div>
        </div>

      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
         {filteredPlayers.map((player) => (
             <div key={player.id} className="flex items-center p-3 border border-gray-100 rounded-lg hover:border-shine-orange/30 hover:shadow-sm transition-all bg-gray-50/50 animate-in fade-in">
                 <div className="w-10 h-10 rounded-full bg-gradient-to-br from-shine-red to-shine-orange text-white flex items-center justify-center font-bold text-sm shadow-sm">
                    {player.name.charAt(0)}
                 </div>
                 <div className="ml-3 flex-1">
                    <div className="font-bold text-gray-800 text-sm">{player.name}</div>
                    <div className="flex items-center gap-2 mt-1">
                        <span className={`text-[10px] uppercase font-bold text-white px-1.5 py-0.5 rounded border border-gray-200 ${
                            player.level === 'N4' ? 'bg-purple-500' :
                            player.level === 'N5' ? 'bg-blue-500' :
                            player.level === 'N6' ? 'bg-green-500' :
                            'bg-yellow-500'
                        }`}>
                            {player.level}
                        </span>
                        <span className="text-[10px] text-gray-500">
                            {player.groupName}
                        </span>
                    </div>
                 </div>
                 {/* Admin could theoretically have an edit button here in future */}
                 {isAdmin && (
                    <div className="text-[10px] text-gray-300">ID: {player.id}</div>
                 )}
             </div>
         ))}
         {filteredPlayers.length === 0 && (
             <div className="col-span-full text-center py-12 border-2 border-dashed border-gray-200 rounded-xl">
                 <Users className="mx-auto h-12 w-12 text-gray-300 mb-3" />
                 <p className="text-gray-500 font-medium">Nenhum jogador encontrado com estes filtros.</p>
                 <button 
                    onClick={() => {setSearchTerm(''); setLevelFilter('TODOS')}}
                    className="mt-2 text-shine-red text-sm font-bold hover:underline"
                 >
                    Limpar filtros
                 </button>
             </div>
         )}
      </div>
    </div>
  );
};

export default PlayerListView;
