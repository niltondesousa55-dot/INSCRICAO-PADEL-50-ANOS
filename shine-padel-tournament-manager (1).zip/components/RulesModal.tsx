import React from 'react';
import { X, Scale } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white w-full max-w-4xl max-h-[90vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-shine-red to-shine-orange p-6 flex justify-between items-center shrink-0">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Scale className="w-6 h-6" /> Regras do Baixinho
          </h2>
          <button 
            onClick={onClose}
            className="text-white/80 hover:text-white hover:bg-white/20 p-2 rounded-full transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="p-8 overflow-y-auto text-gray-700 leading-relaxed space-y-6">
          
          <div className="bg-orange-50 border-l-4 border-shine-orange p-4 italic text-sm text-gray-600 rounded-r">
            "E porque o SHINE gosta de surpreender, o torneio até vai ter regras ... Mas não se assustem, vamos manter brechas e estamos abertos para negociações ao nível do algoritmo."
          </div>

          <section>
            <h3 className="text-xl font-bold text-shine-red mb-3">I. Bem vindos ao 1º Torneio SHINE Padel</h3>
            <p className="mb-2">Conforme prometido, o torneio do SHINE vai mesmo acontecer e até vai ter regras (qb para que ninguém estranhe face ao que são as dinâmicas do dia-a-dia).</p>
            <p className="mb-2">Qualquer sugestão é bem vinda mas só aceitamos sugestões pagas, à velha moda do IBAN do baixinho. Assim evitamos gajos como o Anthony que criticam uma coisa e o seu contrário. Em caso de empate nas vontades vence quem pagar mais ... é apenas uma questão de justiça.</p>
            <p>Quem não concordar pode sempre fazer o seu torneio e criar as suas regras. Já perceberam porque é que pedimos para pagarem antecipadamente ... "Foi Mau"</p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-shine-red mb-3">II. Formato do Torneio</h3>
            <p className="mb-2">O torneio começa com uma 1ª fase com 16 grupos de 4 pessoas. Com a melhor das intenções tentámos agrupar as pessoas em 4 níveis - N4, N5, N6 e N7 ... Sim porque qualquer semelhança entre o ranking do SHINE e a realidade é pura ficção. E no SHINE uma coisa é garantido, vamos sempre dizer-vos a verdade, só não divulgamos o segredo dos wild cards e os perfumes dos fundadores</p>
            <p className="mb-2">Concluída a fase de grupos, seguem-se as fases a eliminar com duplas fixas: Oitavos de Final, Quartos de Final, Meias Final e Final.</p>
            <p className="mb-2">Para os oitavos de final passam os 2 primeiros de cada grupo. Os emparelhamentos já estão todos definidos e os organizadores conseguiram evitar o Cavati até à final. Há malta com sorte nos sorteios ...</p>
            <p className="mb-4">As duplas serão constituídas por 1 primeiro classificado e 1 segundo classificado dos vários grupos.</p>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-bold text-gray-900 mb-2">Classificação e Critérios de Desempate no Grupo:</h4>
              <ul className="list-disc pl-5 space-y-1">
                <li><span className="font-bold">1º A Classificação será por pontos:</span>
                  <ul className="list-[circle] pl-5 mt-1 text-sm text-gray-600">
                    <li>Vitória: 3 Pontos</li>
                    <li>Vitória em Tie Break: 2 Pontos</li>
                    <li>Derrota: 1 Ponto</li>
                    <li>(Os jogos não podem terminar empatados. Em caso de empate joga-se mini tie break até aos 5 pontos)</li>
                  </ul>
                </li>
                <li><span className="font-bold">2º Diferença entre jogos ganhos e perdidos</span></li>
                <li><span className="font-bold">3º Vontade do Baixinho sem direito a recurso</span></li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-bold text-shine-red mb-3">III. Duração dos Jogos</h3>
            <p className="mb-4">Ora aí está uma das primeiras inovações ... todos os jogos da fase de grupos têm a mesma duração.</p>
            <ul className="space-y-3">
              <li>
                <span className="font-bold block text-gray-900">Fase de Grupos</span>
                Jogos de 15 minutos com + 5 para aquecimento, xaxos e bálsamo ... neste último aspecto cuidado com o óleo de escorpião do Nuno nas partes sensíveis, é só uma dica.
              </li>
              <li>
                <span className="font-bold block text-gray-900">Oitavos e Quartos de Final</span>
                Jogos de 20 minutos + 10 para aquecimento, xaxos, pazes (porque há casais e podem haver chatices caso um passe e outro não. Não me atrevo a dizer quem faz a birra, vocês são adultos embora nem sempre pareça) e bálsamos reforçados.
              </li>
              <li>
                <span className="font-bold block text-gray-900">Meias Finais e Final</span>
                Jogos de 25 minutos, o resto mantém-se tudo igual apenas com um tópico adicional – Para os mais cansados podem pedir ao baixinho que coloque o bálsamo e faça uma massagem. Mas calma, já não estamos em Novembro e o símbolo do SHINE não tem nada de azul. Excepções falem no Off.
              </li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-bold text-shine-red mb-3">IV. Estrutura das Equipas (Fases Finais)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                <div className="p-2 border border-gray-100 rounded">Equipa A – 1º Grupo 1 & 2º Grupo 2</div>
                <div className="p-2 border border-gray-100 rounded">Equipa B – 2º Grupo 1 & 1º Grupo 2</div>
                <div className="p-2 border border-gray-100 rounded">Equipa C – 1º Grupo 3 & 2º Grupo 4</div>
                <div className="p-2 border border-gray-100 rounded">Equipa D – 2º Grupo 3 & 1º Grupo 4</div>
                <div className="p-2 border border-gray-100 rounded">Equipa E – 1º Grupo 5 & 2º Grupo 6</div>
                <div className="p-2 border border-gray-100 rounded">Equipa F – 2º Grupo 5 & 1º Grupo 6</div>
                <div className="p-2 border border-gray-100 rounded">Equipa G – 1º Grupo 7 & 2º Grupo 8</div>
                <div className="p-2 border border-gray-100 rounded">Equipa H – 2º Grupo 7 & 1º Grupo 8</div>
                <div className="p-2 border border-gray-100 rounded">Equipa I – 1º Grupo 9 & 2º Grupo 10</div>
                <div className="p-2 border border-gray-100 rounded">Equipa J – 2º Grupo 9 & 1º Grupo 10</div>
                <div className="p-2 border border-gray-100 rounded">Equipa K – 1º Grupo 11 & 2º Grupo 12</div>
                <div className="p-2 border border-gray-100 rounded">Equipa L – 2º Grupo 11 & 1º Grupo 12</div>
                <div className="p-2 border border-gray-100 rounded">Equipa M – 1º Grupo 13 & 2º Grupo 14</div>
                <div className="p-2 border border-gray-100 rounded">Equipa N – 2º Grupo 13 & 1º Grupo 14</div>
                <div className="p-2 border border-gray-100 rounded">Equipa O – 1º Grupo 15 & 2º Grupo 16</div>
                <div className="p-2 border border-gray-100 rounded">Equipa P – 2º Grupo 15 & 1º Grupo 16</div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-bold text-shine-red mb-3">Informações Úteis e Dicas Motivacionais</h3>
            <p className="mb-2">O SHINE é de facto um grupo inclusivo e muito singular. Algumas curiosidades:</p>
            <ul className="list-disc pl-5 space-y-2 text-sm">
                <li>Um líder ditador com um coração maior que ele;</li>
                <li>Um grupo de fundadores que souberam transportar os valores da amizade para uma comunidade que, hoje, deve ter cerca de 250 jogadores menos maus, maus e horríveis ... com algumas (poucas) excepções ... mas todos prontos para uma discutir, rir e beber;</li>
                <li>Único grupo com 6 Djs ... um deles até foi condecorado. Haja alguém que tenha feito alguma coisa pelo país em 50 anos;</li>
                <li>Vários "coaches" ... Mas não se assustem, coach também pode ser visto como tradução de coxo em inglês da "banda";</li>
                <li>Jogadores que semana após semana sentem que não evoluem. Podem sempre tentar trocar de raquete ... ou de desporto. Mas sejam sempre SHINE;</li>
                <li>Uns que fazem tudo para defrontar o Cavati ... Mas depois só expandindo a imagem para se conseguir ver o 0-0-7. Outros (não vou dizer quem) que não trocam as barbies da Disney por nada</li>
            </ul>
            <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded text-center font-medium text-shine-dark">
                "Se o teu parceiro espumar muito com as tuas bolas ao vidro, lembra-lhe que a cerveja tb tem espuma e que no final do jogo resolvem isso no bar"
            </div>
          </section>

        </div>
        
        {/* Footer */}
        <div className="bg-gray-50 p-4 border-t border-gray-100 flex justify-end">
           <button 
             onClick={onClose}
             className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-6 rounded-lg transition-colors"
           >
             Fechar
           </button>
        </div>
      </div>
    </div>
  );
};

export default RulesModal;
