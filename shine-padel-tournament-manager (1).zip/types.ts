
export interface Player {
  id: string;
  name: string;
  level: string; // N4, N5, N6, N7
  groupId: number;
}

export interface MatchResult {
  scoreA: number;
  scoreB: number;
  displayScore?: string; // Stores "6-4", "6-4 6-2", etc.
  isTieBreakWin?: boolean; // If true, winner gets 2 pts instead of 3
}

export interface GroupMatch {
  id: string;
  // Team A
  player1Id: string;
  player2Id: string;
  // Team B
  player3Id: string;
  player4Id: string;
  
  result: MatchResult | null;
  status: 'scheduled' | 'finished';
}

export interface Group {
  id: number;
  name: string;
  players: Player[];
  matches: GroupMatch[];
}

export interface Standing {
  playerId: string;
  points: number;
  played: number;
  won: number;
  lost: number;
  gamesWon: number;
  gamesLost: number;
  diff: number;
}

export interface KnockoutTeam {
  id: string; // "A", "B", "C"...
  name: string;
  player1: Player | null; // From Group X Pos 1
  player2: Player | null; // From Group Y Pos 2
  compositionRule: string; // e.g., "1º Grupo 1 & 2º Grupo 2"
  g1: number;
  g2: number;
  pos1: number;
  pos2: number;
}

export interface KnockoutMatch {
  id: string;
  round: 'round_of_16' | 'quarter_final' | 'semi_final' | 'final';
  teamAId: string;
  teamBId: string;
  score: string | null;
  winnerTeamId: string | null;
  nextMatchId?: string; // To propagate winner
}
